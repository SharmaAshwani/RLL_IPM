import { AdminPolicy } from './admin-policy';

describe('AdminPolicy', () => {
  it('should create an instance', () => {
    expect(new AdminPolicy()).toBeTruthy();
  });
});
