import { UserPolicy } from './user-policy';

describe('UserPolicy', () => {
  it('should create an instance', () => {
    expect(new UserPolicy()).toBeTruthy();
  });
});
