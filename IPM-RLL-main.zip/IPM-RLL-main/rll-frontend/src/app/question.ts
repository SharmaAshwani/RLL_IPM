export class Question {
    
    constructor
    (
        public cid:number,
        public Question:string,
    ){}
}
