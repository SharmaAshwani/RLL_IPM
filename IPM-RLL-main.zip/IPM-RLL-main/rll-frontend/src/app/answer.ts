export class Answer {
    
    constructor
    (
        
        public Ansid:number,
        public Answer:string,
    
    ){}

}
