export class UserPolicy {
    constructor(public userid:number,
        public policyname:string,
        public name:string,
        public applieddate:string,
        public status:string){}
}
