export class AdminPolicy {
    constructor(public policyid:number,
        public policyname:string,
        public category:number,
        public amount:string,
        public features:string){}
}
