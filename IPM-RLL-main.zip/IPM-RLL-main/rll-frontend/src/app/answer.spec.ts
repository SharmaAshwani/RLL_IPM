import { Answer } from './answer';

describe('Answer', () => {
  it('should create an instance', () => {
    expect(new Answer()).toBeTruthy();
  });
});
